package ua.nure.matsak.task1;

public class Demo {
    public static void main(String[] args) {
        System.out.println("----------Part1----------");
        System.out.println("Input: 10 20 50");
        Part1.main(new String[]{"10", "20", "50"});
        System.out.println("\n");

        System.out.println("----------Part2----------");
        System.out.println("Input: jxg &&& 55? lkjd560*(");
        Part2.main(new String[]{"jxg", "&&&", "55?", "lkjd560*("});
        System.out.println("\n");

        System.out.println("----------Part3----------");
        System.out.println("Input: 42 12");
        Part3.main(new String[]{"42", "12"});
        System.out.println("\n");

        System.out.println("----------Part4----------");
        System.out.println("Input: 42 12");
        Part4.main(new String[]{"asdf123", "4gh56", "jk", "11", "2f"});
        System.out.println("\n");

        System.out.println("----------Part5----------");
        System.out.println("Input: 10");
        Part5.main(new String[]{"10"});
        System.out.println("\n");

        System.out.println("----------Part6----------");
        System.out.println("Input: 480");
        Part6.main(new String[]{"480"});
        System.out.println("\n");

        System.out.println("----------Part7----------");
        System.out.println("Input: 90");
        Part7.main(new String[]{"90"});
        System.out.println("\n");

        System.out.println("----------Part8----------");
        System.out.println("Input: 5");
        Part8.main(new String[]{"5"});
        System.out.println("\n");

        System.out.println("----------Part9----------");
        System.out.println("Input: 112");
        Part5.main(new String[]{"112"});
        System.out.println("\n");
    }
}
